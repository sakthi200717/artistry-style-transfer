# QuickArt Studio — upgraded Flask project

## Features
- Artistic transformations: pencil sketch, charcoal, watercolor, oil-painting-like effect, vintage, ink outline, cartoon.
- Background replacement: remove the subject's background and place it over a solid color or a user-uploaded background image.
- Persistent SQLite processing history with operation name, original filename, timestamp, result thumbnail, and elapsed processing time.
- Download results and clear history.
- `loss_functions.py`: PyTorch content loss, Gram-matrix style loss, total variation loss, and a weighted combined loss function for neural style-transfer optimization.

## Important note about loss functions
The current interactive app uses fast image-processing effects for the named artistic presets. The PyTorch loss module is included for an actual neural style-transfer optimization/training workflow; the preset effects do not pretend to be trained by these losses. To run genuine VGG-based neural style transfer, a feature-extractor/optimization pipeline must call these functions.

## Windows PowerShell setup
Open PowerShell inside the extracted `QuickArt_Upgrade` folder and run these commands one at a time:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

Then open http://127.0.0.1:5000 in your browser.

## Notes
- First installation downloads dependencies and can take a few minutes.
- First background removal may take longer while the CPU model is initialized/downloaded.
- Maximum uploaded file size is 12 MB. Accepted formats: PNG, JPG/JPEG, WEBP.
- History and images are stored locally in `history.db` and `static/uploads`, `static/outputs`.
- For a public deployment, set a strong `QUICKART_SECRET`, disable Flask debug mode, and add authentication/CSRF protection.


## Loss Function Graph

Open **Loss graph** in the top navigation or visit `/loss-graph`. The page shows an illustrative Chart.js loss curve preview. It is explicitly labeled as illustrative because the current preset-filter operations do not perform neural optimization and therefore do not generate measured loss values. To show real curves, log the content/style/total-variation losses from a neural style-transfer optimization loop and feed those values into the chart. The graph uses Chart.js from a CDN, so an internet connection is needed to render it.
