"""Loss functions for neural style-transfer training/optimization.

These are reusable PyTorch losses. The current QuickArt UI uses fast image effects;
these functions are provided for a genuine neural-style-transfer extension and are
not falsely reported as training losses for the preset filter operations.
"""
import torch
import torch.nn.functional as F


def content_loss(generated_features, content_features):
    """Preserve the image's structure/content using mean-squared error."""
    return F.mse_loss(generated_features, content_features)


def gram_matrix(features):
    """Compute channel correlations used to represent artistic texture/style."""
    b, c, h, w = features.shape
    x = features.reshape(b, c, h * w)
    gram = torch.bmm(x, x.transpose(1, 2))
    return gram / (c * h * w)


def style_loss(generated_features, style_features):
    """Match style feature correlations between generated and reference artwork."""
    return F.mse_loss(gram_matrix(generated_features), gram_matrix(style_features))


def total_variation_loss(image):
    """Reduce noisy pixel-to-pixel variation while retaining visual detail."""
    vertical = torch.mean(torch.abs(image[:, :, 1:, :] - image[:, :, :-1, :]))
    horizontal = torch.mean(torch.abs(image[:, :, :, 1:] - image[:, :, :, :-1]))
    return vertical + horizontal


def total_style_transfer_loss(generated_features, content_features,
                              style_feature_pairs, generated_image,
                              content_weight=1.0, style_weight=100000.0,
                              tv_weight=1e-5):
    """Combined objective: content + style + smoothness.

    style_feature_pairs is an iterable of (generated_layer_features,
    reference_style_layer_features) pairs. Tune weights for your model/layers.
    """
    c_loss = content_loss(generated_features, content_features)
    s_loss = sum(style_loss(gf, sf) for gf, sf in style_feature_pairs)
    tv_loss = total_variation_loss(generated_image)
    total = content_weight * c_loss + style_weight * s_loss + tv_weight * tv_loss
    return total, {"content": c_loss, "style": s_loss, "total_variation": tv_loss}
