import os, io, time, uuid, sqlite3
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash
from PIL import Image, ImageFilter, ImageOps, ImageEnhance
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

BASE = Path(__file__).resolve().parent
UPLOAD_DIR = BASE / 'static' / 'uploads'
OUTPUT_DIR = BASE / 'static' / 'outputs'
HISTORY_DIR = BASE / 'static' / 'history'
DB_PATH = BASE / 'history.db'
for folder in (UPLOAD_DIR, OUTPUT_DIR, HISTORY_DIR): folder.mkdir(parents=True, exist_ok=True)
app = Flask(__name__)
app.secret_key = os.environ.get('QUICKART_SECRET', 'quickart-local-dev-key-change-me')
app.config['MAX_CONTENT_LENGTH'] = 12 * 1024 * 1024
ALLOWED = {'.png', '.jpg', '.jpeg', '.webp'}


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            original_name TEXT NOT NULL,
            input_file TEXT NOT NULL,
            output_file TEXT NOT NULL,
            operation TEXT NOT NULL,
            duration_seconds REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'Success'
        )''')

init_db()


def safe_image(file_storage, target_path):
    ext = Path(file_storage.filename or '').suffix.lower()
    if ext not in ALLOWED:
        raise ValueError('Please upload a PNG, JPG, JPEG, or WEBP image.')
    im = Image.open(file_storage.stream)
    im = ImageOps.exif_transpose(im).convert('RGB')
    im.thumbnail((1800, 1800))
    im.save(target_path, quality=94)
    return im


def apply_style(im, style):
    im = im.convert('RGB')
    if style == 'Pencil sketch':
        gray = ImageOps.grayscale(im)
        inv = ImageOps.invert(gray).filter(ImageFilter.GaussianBlur(12))
        a, b = np.asarray(gray).astype(np.float32), np.asarray(inv).astype(np.float32)
        out = np.clip(a * 255.0 / np.maximum(1, 255-b), 0, 255).astype('uint8')
        return Image.fromarray(out).convert('RGB')
    if style == 'Charcoal':
        gray = ImageOps.grayscale(im).filter(ImageFilter.FIND_EDGES)
        gray = ImageOps.invert(gray)
        gray = ImageEnhance.Contrast(gray).enhance(2.2)
        return Image.merge('RGB', (gray, gray, gray))
    if style == 'Watercolor':
        if cv2 is not None:
            arr = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)
            smooth = cv2.bilateralFilter(arr, 9, 90, 90)
            try:
                color = cv2.stylization(smooth, sigma_s=60, sigma_r=0.45)
                return Image.fromarray(cv2.cvtColor(color, cv2.COLOR_BGR2RGB))
            except Exception:
                pass
        return ImageEnhance.Color(im.filter(ImageFilter.SMOOTH_MORE)).enhance(1.35)
    if style == 'Oil painting':
        if cv2 is not None:
            arr = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)
            try:
                out = cv2.xphoto.oilPainting(arr, 7, 1)
                return Image.fromarray(cv2.cvtColor(out, cv2.COLOR_BGR2RGB))
            except Exception:
                pass
        return ImageEnhance.Color(im.filter(ImageFilter.SMOOTH_MORE)).enhance(1.5)
    if style == 'Vintage':
        arr = np.asarray(im).astype(np.float32)
        mat = np.array([[0.393,0.769,0.189],[0.349,0.686,0.168],[0.272,0.534,0.131]])
        return Image.fromarray(np.uint8(np.clip(arr @ mat.T, 0, 255)))
    if style == 'Ink outline':
        edge = ImageOps.grayscale(im).filter(ImageFilter.FIND_EDGES)
        edge = ImageOps.invert(edge).point(lambda p: 255 if p > 150 else 0)
        return Image.merge('RGB', (edge, edge, edge))
    if style == 'Cartoon':
        if cv2 is not None:
            arr = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)
            color = cv2.bilateralFilter(arr, 9, 250, 250)
            gray = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
            gray = cv2.medianBlur(gray, 7)
            edges = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 9, 9)
            out = cv2.bitwise_and(color, color, mask=edges)
            return Image.fromarray(cv2.cvtColor(out, cv2.COLOR_BGR2RGB))
        return ImageEnhance.Color(im.filter(ImageFilter.CONTOUR)).enhance(1.4)
    return im


def replace_background(subject_path, background_path=None, color='#e9eef5'):
    try:
        from rembg import remove
    except ImportError:
        raise RuntimeError('Background removal needs rembg. Run: python -m pip install rembg')
    subject = Image.open(subject_path).convert('RGBA')
    cutout = remove(subject)
    if not isinstance(cutout, Image.Image): cutout = Image.open(io.BytesIO(cutout)).convert('RGBA')
    cutout.thumbnail((1600, 1600))
    if background_path:
        bg = Image.open(background_path).convert('RGB')
        bg = ImageOps.fit(bg, cutout.size, method=Image.Resampling.LANCZOS)
    else:
        bg = Image.new('RGB', cutout.size, color)
    bg.paste(cutout, (0, 0), cutout.getchannel('A'))
    return bg


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        started = time.perf_counter()
        up = request.files.get('image')
        operation = request.form.get('operation', 'Pencil sketch')
        if not up or not up.filename:
            flash('Choose an image first.', 'error'); return redirect(url_for('index'))
        uid = uuid.uuid4().hex[:12]
        input_name, output_name = f'{uid}_input.jpg', f'{uid}_output.jpg'
        input_path, output_path = UPLOAD_DIR / input_name, OUTPUT_DIR / output_name
        bg_upload = request.files.get('background')
        bg_path = None
        try:
            im = safe_image(up, input_path)
            if operation == 'Background replacement':
                if bg_upload and bg_upload.filename:
                    ext = Path(bg_upload.filename).suffix.lower()
                    if ext not in ALLOWED: raise ValueError('Background image must be PNG, JPG, JPEG, or WEBP.')
                    bg_name = f'{uid}_background{ext}'
                    bg_path = UPLOAD_DIR / bg_name
                    bg_upload.save(bg_path)
                result = replace_background(input_path, str(bg_path) if bg_path else None, request.form.get('bg_color', '#e9eef5'))
            else:
                result = apply_style(im, operation)
            result.convert('RGB').save(output_path, quality=95)
            elapsed = round(time.perf_counter() - started, 3)
            with db() as con:
                con.execute('INSERT INTO history(created_at, original_name, input_file, output_file, operation, duration_seconds, status) VALUES(?,?,?,?,?,?,?)',
                            (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), Path(up.filename).name, input_name, output_name, operation, elapsed, 'Success'))
            flash(f'Completed in {elapsed:.2f} seconds.', 'success')
            return redirect(url_for('result', filename=output_name))
        except Exception as exc:
            for p in (input_path, output_path, bg_path):
                if p and Path(p).exists():
                    try: Path(p).unlink()
                    except OSError: pass
            flash(str(exc), 'error')
            return redirect(url_for('index'))
    return render_template('index.html')


@app.route('/result/<filename>')
def result(filename):
    with db() as con:
        row = con.execute('SELECT * FROM history WHERE output_file=?', (filename,)).fetchone()
    if not row: return redirect(url_for('index'))
    return render_template('result.html', row=row)


@app.route('/loss-graph')
def loss_graph():
    return render_template('loss_graph.html')


@app.route('/history')
def history():
    with db() as con:
        rows = con.execute('SELECT * FROM history ORDER BY id DESC LIMIT 100').fetchall()
    return render_template('history.html', rows=rows)


@app.route('/uploads/<path:filename>')
def uploaded(filename):
    return send_from_directory(UPLOAD_DIR, filename)

@app.route('/outputs/<path:filename>')
def output(filename):
    return send_from_directory(OUTPUT_DIR, filename)

@app.route('/history/clear', methods=['POST'])
def clear_history():
    with db() as con:
        rows = con.execute('SELECT input_file, output_file FROM history').fetchall()
        con.execute('DELETE FROM history')
    for row in rows:
        for folder, key in ((UPLOAD_DIR, 'input_file'), (OUTPUT_DIR, 'output_file')):
            try: (folder / row[key]).unlink(missing_ok=True)
            except OSError: pass
    flash('Processing history cleared.', 'success')
    return redirect(url_for('history'))

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
