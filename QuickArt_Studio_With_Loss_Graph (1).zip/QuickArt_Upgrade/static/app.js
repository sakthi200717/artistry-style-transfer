const imageInput = document.getElementById('imageInput');
const preview = document.getElementById('preview');
if (imageInput) imageInput.addEventListener('change', () => {
  const file = imageInput.files && imageInput.files[0];
  if (!file) return;
  preview.src = URL.createObjectURL(file); preview.hidden = false;
});
const operation = document.getElementById('operation');
const bgOptions = document.getElementById('bgOptions');
function updateBgOptions(){ if(operation && bgOptions) bgOptions.style.display = operation.value === 'Background replacement' ? 'block' : 'none'; }
if(operation){ operation.addEventListener('change', updateBgOptions); updateBgOptions(); }
const form = document.getElementById('artForm');
if(form) form.addEventListener('submit', () => { const btn=document.getElementById('submitBtn'); btn.disabled=true; btn.innerHTML='Working…'; document.getElementById('loadingHint').hidden=false; });
